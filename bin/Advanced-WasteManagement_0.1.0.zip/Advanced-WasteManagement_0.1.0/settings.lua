data:extend({
    {
          type = "bool-setting",
          name = "AWM-OnlyInflammable",
          setting_type = "startup",
          default_value = "false",
      },
  })