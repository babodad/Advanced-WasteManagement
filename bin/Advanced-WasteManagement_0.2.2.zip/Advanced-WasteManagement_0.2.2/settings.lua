data:extend({
    {
          type = "bool-setting",
          name = "AWM-EverythingBurns",
          setting_type = "startup",
          default_value = "false",
      },
  })