data:extend(
{
  {
    type = "fuel-category",
    name = "incinerator"
  }
})
require("prototypes.incinerator")
