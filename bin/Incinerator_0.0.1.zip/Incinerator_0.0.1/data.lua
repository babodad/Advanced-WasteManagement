data:extend(
{
  {
    type = "fuel-category",
    name = "incernator"
  }
})
require("prototypes.incernator")
