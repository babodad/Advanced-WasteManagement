require("prototypes.entity")
require("prototypes.item")
require("prototypes.recipe")
--require("prototypes.technology")

data:extend(
{
  {
    type = "fuel-category",
    name = "incinerator"
  }
})
